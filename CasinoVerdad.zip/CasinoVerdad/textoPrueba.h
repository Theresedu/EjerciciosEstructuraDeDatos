#ifndef TEXTO_PRUEBA_H
#define TEXTO_PRUEBA_H

#include <iostream>
#include <vector>
#include <string>
#include <thread>
#include <chrono>

using namespace std;

class TextoPrueba {
public:
    //TextoPrueba();  // Constructor
    void imprimirTexto();  // Método para imprimir el texto en forma de arte ASCII
};

#endif

