#ifndef REGISTRO_H
#define REGISTRO_H

#include <iostream>
#include <string>

using namespace std;

class Registro {
private:
    string nombre;
    string apellido;
    string cedula;
    int edad;
    double monto;
    string fechaRegistro;
public:
    void borrar(char a[]);
    bool extraer(const string& cedula); // Validación de cédula
    void guardarRegistro(const string& nombre, const string& apellido, const string& cedula, int edad, double monto); // Guardar los datos en un archivo
    bool registrarUsuario();  // Registrar el usuario
    string obtenerEntrada(bool soloNumeros); // Obtener entrada del usuario, permitiendo solo números o letras
    string obtenerFechaHora();  // Obtener la fecha y hora actual
};

#endif // REGISTRO_H
